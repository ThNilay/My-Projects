import pygame, time, random

pygame.init()

width, height = 800, 600
block, speed = 20, 15

clock = pygame.time.Clock()

font = pygame.font.SysFont(None, 25)

display = pygame.display.set_mode((width, height))
pygame.display.set_caption('Naagraj')

def msg(msg, color):
    txt = font.render(msg, True, color)
    display.blit(txt, [width / 6, height / 2])

def snake(block, snake_list):
    for x in snake_list:
        pygame.draw.rect(display, (0, 0, 0), [x[0], x[1], block, block])

def score(score):
    value = font.render("Score: " + str(score), True, (0, 0, 0))
    display.blit(value, [0, 0])

def game():
    exit, over = False, False

    lead_x, lead_y = width / 2, height / 2
    lead_x_c, lead_y_c = 0, 0

    snake_list, snake_len = [], 1

    apple_x = round(random.randrange(0, width - block) / float(block)) * block
    apple_y = round(random.randrange(0, height - block) / float(block)) * block

    while not exit:

        while over == True:
            display.fill((255, 255, 255))
            msg("Game Over, press C to play again or Q to quit", (255, 0, 0))
            score(snake_len - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit, over = True, False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        exit, over = True, False
                    if event.key == pygame.K_c:
                        game()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    lead_x_c = -block
                    lead_y_c = 0
                elif event.key == pygame.K_RIGHT:
                    lead_x_c = block
                    lead_y_c = 0
                elif event.key == pygame.K_UP:
                    lead_y_c = -block
                    lead_x_c = 0
                elif event.key == pygame.K_DOWN:
                    lead_y_c = block
                    lead_x_c = 0

        if lead_x >= width or lead_x < 0 or lead_y >= height or lead_y < 0:
            over = True

        lead_x += lead_x_c
        lead_y += lead_y_c

        display.fill((255, 255, 255))
        pygame.draw.rect(display, (255, 0, 0), [apple_x, apple_y, block, block])

        head = []
        head.append(lead_x)
        head.append(lead_y)
        snake_list.append(head)

        if len(snake_list) > snake_len:
            del snake_list[0]

        for seg in snake_list[:-1]:
            if seg == head:
                over = True

        snake(block, snake_list)
        score(snake_len - 1)

        pygame.display.update()

        if lead_x == apple_x and lead_y == apple_y:
            apple_x = round(random.randrange(0, width - block) / float(block)) * block
            apple_y = round(random.randrange(0, height - block) / float(block)) * block
            snake_len += 1

        clock.tick(speed)

    pygame.quit()
    quit()

game()
