# Hey Soubhik this is a Stack DS
# I am comparing the stack to a box to better explain it

# I am creating an empty stack
def create_stack():
    stack = []  # Make an empty box called "stack"
    return stack  # Give the box to the person who wanted it


# Here we will Check if the stack is empty
def check_empty(stack):
    return len(stack) == 0 # Look inside the box and see if it's empt


# We will add items to the stack
def push(stack, item):
    stack.append(item) # Put something new into the box
    print("pushed item: " + item) # Tell what we put into the box


# Remove an item from the stack
def pop(stack):
    if (check_empty(stack)): # If the box is empty
        return "stack is empty" # Tell that there's nothing to take out

    return stack.pop() # Take something out of the box


stack = create_stack() # Get an empty box to play with
push(stack, str(69)) # Putting the number 69 into the box
push(stack, str(71)) # Putting the number 71 into the box
push(stack, str(3)) # Putting the number 3 into the box
push(stack, str(41)) # Putting the number 41 into the box
print("popped item: " + pop(stack)) # Take something out of the box and say what it is
print("stack after popping an element: " + str(stack)) #show what's left in the box after we take out the first item
