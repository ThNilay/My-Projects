# Hey Soubhik ! here I have implemented a Selection Sort algorithm
#This algorithm sorts the no. from smallest to biggest
#I will try to use the comments to explain to code to you in simple terms (layman terms)


def selectionSort(array, size): # This is saying, "Let's look at each number one by one."


	for a in range(size):
		min_idx = a   # We're pretending that the first number we see is the smallest.
		

		# Now, we're checking all the other numbers to see if any are smaller than the one we pretended was smallest.
		for i in range(a + 1, size):
			
			if array[i] < array[min_idx]:  # If we find a smaller number.
				min_idx = i  # then we remember its position.


		# After checking all the numbers, we swap the smallest one we found with the first number we looked at.
		(array[a], array[min_idx]) = (array[min_idx], array[a])

		


data = [ 5, 7, 8, 3, 2] # Here are some numbers we are going to sort.
size = len(data)  # This will tell us how many numbers there are.
selectionSort(data, size)

print('Sorted Array in Ascending Order is :') 
print(data) # We show the sorted numbers.
