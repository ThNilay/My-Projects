Hello, My name is Nilay

In this folder, you can see two files.

The first is named Selectionsort.py, In this file I have implemented a selection sort algorithm in Python. I have used the comments to describe the code line by line in a ELI5 fashion.

The second file is named Stack.py, In this file I have implemented a stack in python. It's very basic. Here too I have used the comments to describe the code line by line in a ELI5 fashion.

 
.